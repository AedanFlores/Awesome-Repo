extends CanvasLayer
func _on_menu_button_button_down() -> void:

	$MenuButton.hide()
	$MenuButton.disabled=true
	$Continue.show()
	$Continue.disabled=false 
	$RestartGame.show()
	$RestartGame.disabled=false 
	$QuitGame.show()
	$QuitGame.disabled=false 
	pass # Replace with function body.


func _on_continue_button_down() -> void:
	$MenuButton.show()
	$MenuButton.disabled=false
	$Continue.hide()
	$Continue.disabled=true
	$RestartGame.hide()
	$RestartGame.disabled=true
	$QuitGame.hide()
	$QuitGame.disabled=true
	pass # Replace with function body.


func _on_restart_game_button_down() -> void:
	get_tree().change_scene_to_file("res://Scenes/start_menu.tscn")
	pass # Replace with function body.


func _on_quit_game_button_down() -> void:
	get_tree().quit()
	pass # Replace with function body.
