extends MenuButton


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	var popup = $MenuButton.get_popup()
	popup.add_item("New Game", 0)
	popup.add_item("Load Game", 1)
	popup.add_separator()
	popup.add_item("Quit", 2)
	popup.id_pressed.connect(_on_menu_item_pressed)

	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
func _on_menu_item_pressed(id):
	match id:
		0:
			get_tree().change_scene_to_file("res://Scenes/level_1.tscn")
		1:
			print("Load game")
		2:
			get_tree().quit()
